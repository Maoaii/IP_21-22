/**
 * @author Lucas Girotto 
 * Plot class. Holds all the information regarding a single Plot, like the
 * amount of treasure it has or if it has been dug up.
 */
public class Plot {

	// Constants
	private static final int MERIT_LOSS = 10;

	// Plot Instance variables
	private int treasure;
	private int meritLossMultiplier;
	private boolean dugUp;

	/**
	 * Plot Constructor
	 * 
	 * @param treasure to assign to this plot
	 * @pre treasure != null
	 */
	public Plot(int treasure) {
		this.treasure = treasure;
		dugUp = false;
		meritLossMultiplier = 1;
	}

	/**
	 * @return treasure value on this plot
	 */
	public int getTreasure() {
		return treasure;
	}

	/**
	 * @return true if this plot has treasure, false if it does not
	 */
	public boolean hasTreasure() {
		if (treasure == 0)
			return false;

		return true;
	}

	/**
	 * When this plot is excavated, make it dug up and remove its' treasure
	 */
	public void excavated() {
		dugUp = true;
		treasure = 0;
	}

	/**
	 * @return true if this plot has been dug up, false if it hasn't
	 */
	public boolean isDugUp() {
		return dugUp;
	}

	/**
	 * @return the amount of merit the Archeologist is going to lose
	 */
	public int meritLoss() {
		return MERIT_LOSS * meritLossMultiplier++;
	}
}
